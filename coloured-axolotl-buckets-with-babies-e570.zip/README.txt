--- Requirments For Use ---
The pack uses CIT so you can use:
Optifine
https://optifine.net/downloads
or
CIT Resewn
https://www.curseforge.com/minecraft/mc-mods/cit-resewn

--- Social Links ---
Twitter: @KyleJ_A29
https://twitter.com/KyleJ_A29

Planet Minecraft: Blazified
https://www.planetminecraft.com/member/blazified/

--- Copyright ---
I do not provide any original files from Minecraft in this pack.
This pack only contains derivative works.
Feel free to uses thes textures for other projects but give some credit!
Such as a link to the orignal place you found the textures.

--- End ---
Hope you enjoy the textures!