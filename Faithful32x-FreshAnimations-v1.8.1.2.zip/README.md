# FA-Faithful32

Add on for Fresh Animations to make faithful 32 compatible.

# Pack Order
Faithful and Fresh Animations must be installed for this pack to function correctly\
This is how the packs should apear in your resource pack list

- This Add-on
- [Faithful32](https://faithfulpack.net/)
- [Fresh Animations](https://www.planetminecraft.com/texture-pack/fresh-animations-v1-0/)

# Credits
Space Burger Owner#0095\
Wooferscoots#5483\
Псевдопсевдогипопаратиреоз

<https://www.planetminecraft.com/texture-pack/fresh-animations-v1-0/> \
<https://www.curseforge.com/minecraft/texture-packs/fresh-animations/files> \
FreshLX_official

<https://faithfulpack.net/> \
cats - jogurciQ, Alexsor\
cow - Mr. Confused, TheOPWarrior208, DMgaming\
enderman -Alexsor\
fox - Tekayo, HARAG0N_MC\
horse - Hozz, DMgaming, HARAG0N_MC, Aerod\
illager - DMgaming, Fabri, jogurciQ\
iron_gollem -jogurciQ\
llama - DMgaming, Nyodex, HARAG0N_MC\
pig - BellPepperBrian, Pythagoras_314, DMgaming\
sheep - DMgaming\
skeleton - Alexsor\
spider - Alexsor\
turtle - Zeuselpro, Aerod\
villager - DMgaming, Fabri\
wolf - Alexsor\
zombie - Alexsor\
zombie_villager - DMgaming, Fabri\
blaze - jogurciQ\
chicken - Alexsor\
dolphin - Pythagoras_314\
wandering_trader - jogurciQ\
witch - jogurciQ, Fabri
